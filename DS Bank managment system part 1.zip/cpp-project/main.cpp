#include <iostream>
using namespace std;
int main() {
    int queue[5];
    int front;
    int rear;
    front=-1;
    rear=-1;
    int x;
    for(int i=0;i<5;i++){
        if(front=-1){
            front=0;
        }
        cout<<"Enter token:"<<endl;
        cin>>queue[i];
        cout<<"Token added:"<<endl;
    }
    cout<<"added tokens:"<<endl;
    for(int i=0;i<5;i++){
        cout<<queue[i]<<" ";
    }
    return 0;
}
